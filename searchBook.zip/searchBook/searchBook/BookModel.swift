//
//  BookModel.swift
//  searchBook
//
//  Created by 더가치 on 4/17/24.
//

import Foundation

struct Book {
    let title: String
    let author: String
    let price: Int
}

