//
//  Connection.swift
//  searchBook
//
//  Created by 더가치 on 4/17/24.
//

import Foundation
import Alamofire
import SwiftyJSON

class Connection {
    
    func getBook() {
        
        let param = [
            "query" : "듄"
        ]
        //        var components = URLComponents(string: "")
        
        let baseURL = URL(string: "https://dapi.kakao.com/v3/search/book")!
        let headers: HTTPHeaders = [
            "Authorization": "KakaoAK 77e2466b28d175a0fce104894014bc50"
            // "Accept": "application/json"
        ]
        
        let alamo = AF.request(baseURL , method: .get, parameters: param, headers: headers)
        
        alamo.responseJSON { response in
            switch response.result {
            case .success(let data):
                let json = JSON(data)
                var dicData: Dictionary<String, Any> = [String : Any]()
                do {
                    dicData = json.rawValue as! [String : Any]
                } catch {
                    print(error.localizedDescription)
                }
                
                print(dicData["documents"])
                
                let documents: [String : Any] = dicData["documents"] as! [String : Any]
                

//                let result:[Book] = documents.map { element in
//                    
//                    let books = Book(title: documents[""] as! String, author: <#String#>, price: <#Int#>)
//                    
//                }
                
                if let d = data as? [[String : Any]] {
                    let documents = d.map { element in element["documents"]}
                    
                    print(documents)
                    

//
//                        
                        
//                    
////                        print(books)
////                        return books
//                    }
                    
                }
                
                
                
//                BookListViewModel().books = [Book(title: <#T##String#>, author: <#T##String#>, pageCount: <#T##Int#>)]
                
                // json dictionary -> 뷰 모델
                
                
                //                self.tableView.reloadData()
                break
            case .failure:
                
                break
            }
        }
        
//        alamo.responseDecodable(of: 모델)(completionHandler: <#T##(DataResponse<Decodable, AFError>) -> Void#>)
        
        
        
        
    }
    
    // 1. VO 로 값 전달
    // 2. VM 으로 값 전달
    
}
