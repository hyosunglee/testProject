//
//  BookTableViewCell.swift
//  searchBook
//
//  Created by 더가치 on 4/17/24.
//

import UIKit

class BookTableViewCell: UITableViewCell {
    
    @IBOutlet weak var label_title: UILabel!
    @IBOutlet weak var label_authors: UILabel!
    @IBOutlet weak var label_datetime: UILabel!
    @IBOutlet weak var label_sale_price: UILabel!
    @IBOutlet weak var image_thumbnail: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
