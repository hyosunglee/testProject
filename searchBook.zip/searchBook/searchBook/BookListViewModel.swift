//
//  BookListViewModel.swift
//  searchBook
//
//  Created by 더가치 on 4/17/24.
//

import Foundation

class BookListViewModel {
    
    // private
    var books: [Book] = []
    
    func fetchBooks() {
        // 여기서는 간단한 예시로 정적인 도서 목록을 사용합니다.
        books = [
            Book(title: "죽음의 외치기", author: "알버트 카뮈", price: 256),
            Book(title: "1984", author: "조지 오웰", price: 328),
            Book(title: "어린 왕자", author: "생텍쥐페리", price: 96)
        ]
    }
    
    func numberOfBooks() -> Int {
        return books.count
    }
    
    func book(at index: Int) -> Book? {
        guard index >= 0 && index < books.count else { return nil }
        return books[index]
    }
}

