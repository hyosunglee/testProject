//
//  ViewController.swift
//  searchBook
//
//  Created by 더가치 on 4/17/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    
    var viewModel = BookListViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Connection().getBook()
        
        self.table.dataSource = self
        self.table.reloadData()
    }


}


extension ViewController: UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfBooks()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BookTableViewCell", for: indexPath) as! BookTableViewCell
        
        if let book = viewModel.book(at: indexPath.row) {
            
            cell.label_title.text = book.title
        }
        
        
        return cell
    }

}

